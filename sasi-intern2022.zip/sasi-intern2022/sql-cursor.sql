set serveroutput on

declare 
       PF  number(8);
       meno emp.empno%type;
       mename emp.ename%type;
       msal   emp.sal%type;
       cursor c1 is select empno,ename,sal from emp order by empno;
begin
      dbms_output.put_line('Employee Pay Slip');
      dbms_output.put_line('-----------------');

      open c1;
     loop
            dbms_output.put_line('EMP NO:='||meno);
            fetch c1 into meno,mename,msal;
            exit when c1%notfound;
            pf := msal*.20;
            dbms_output.put_line('NAME  :='||mename);
            dbms_output.put_line('PF    :=' || pf);

     end loop;
     exception when others then
     dbms_output.put_line('Error'||sqlerrm);
end;
/

set serveroutput on

declare
       a  number := 10 ;
       b  number :=0;
begin
      dbms_output.put_line(' Number List');
 
 for i in 1..a loop

            b := b + 4;

             dbms_output.put_line(i||'+4='||b);

      end loop;
end;
/

set serveroutput on
Declare
 s varchar2(20):='&s';

 s1 varchar2(20);

begin

   for I in  reverse 1 .. Length(s) loop

         s1:=s1||substr(s,I,1);

   end loop;

dbms_output.put_line('The Reverse String is ' || s1);

end;
/

set serveroutput on
declare 
       tot  number(8) :=0;
       cursor c1 is select name,rollno,average,result from marklist1 order by 1;
begin
      dbms_output.put_line('Marklist details');
      dbms_output.put_line('-----------------');
      for i in c1 loop
            dbms_output.put_line(i.Rollno   ||   i.Name   ||   i.average   ||  i.result);
            tot := tot+i.average;
       end loop;
           dbms_output.put_line('AVERAGE TOTAL :='||tot);
end;
/

